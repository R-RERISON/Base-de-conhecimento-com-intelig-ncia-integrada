<?php
/**
 * Persistência reconstruível da Search Retrieval Projection.
 *
 * @package BDC_Knowledge_Base
 */

namespace BDC\KnowledgeBase;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Search_Projection_Repository {

	public const SCHEMA_VERSION = '1.1.0';
	public const STATE_OPTION = 'bdc_kb_search_projection_state';
	public const CANDIDATE_CAP = 200;
	public const SECTION_PARENT_CAP = 20;
	public const UPSERT_WRITTEN = 'WRITTEN';
	public const UPSERT_NO_CHANGE = 'NO_CHANGE';

	/** @var array<int,string> */
	private const SEARCH_FIELDS = array(
		'title_norm',
		'summary_norm',
		'headings_norm',
		'taxonomy_norm',
		'body_norm',
	);

	/** @var array<int,string> */
	private const REQUIRED_COLUMNS = array(
		'post_id',
		'document_state',
		'source_kind',
		'title_norm',
		'summary_norm',
		'headings_norm',
		'taxonomy_norm',
		'body_norm',
		'sections_json',
		'section_projection_version',
		'source_hash',
		'document_hash',
		'document_version',
		'normalizer_version',
		'post_modified_gmt',
		'indexed_at_gmt',
	);

	/** @var array<int,string> */
	private const REQUIRED_INDEXES = array( 'PRIMARY', 'document_state', 'document_version', 'source_hash' );

	public static function table_name(): string {
		global $wpdb;
		return $wpdb->prefix . 'bdc_kb_search_documents';
	}

	/**
	 * Criação explícita do schema. Não é chamada em page load.
	 */
	public static function ensure_schema(): void {
		global $wpdb;

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$table = self::table_name();
		$charset = $wpdb->get_charset_collate();

		$sql = "CREATE TABLE {$table} (
			post_id BIGINT UNSIGNED NOT NULL,
			document_state VARCHAR(16) NOT NULL,
			source_kind VARCHAR(32) NOT NULL,
			title_norm TEXT NOT NULL,
			summary_norm LONGTEXT NOT NULL,
			headings_norm LONGTEXT NOT NULL,
			taxonomy_norm LONGTEXT NOT NULL,
			body_norm LONGTEXT NOT NULL,
			sections_json LONGTEXT NOT NULL,
			section_projection_version VARCHAR(32) NOT NULL,
			source_hash CHAR(64) NOT NULL,
			document_hash CHAR(64) NOT NULL,
			document_version VARCHAR(32) NOT NULL,
			normalizer_version VARCHAR(32) NOT NULL,
			post_modified_gmt DATETIME NULL,
			indexed_at_gmt DATETIME NOT NULL,
			PRIMARY KEY  (post_id),
			KEY document_state (document_state),
			KEY document_version (document_version),
			KEY source_hash (source_hash)
		) {$charset};";

		dbDelta( $sql );
	}

	/**
	 * @return array<string,mixed>
	 */
	public static function state(): array {
		$state = get_option( self::STATE_OPTION, array() );
		return is_array( $state ) ? $state : array();
	}

	public static function is_ready(): bool {
		$state = self::state();

		return 'ready' === (string) ( $state['status'] ?? '' )
			&& self::SCHEMA_VERSION === (string) ( $state['schema_version'] ?? '' )
			&& Search_Document_Builder::VERSION === (string) ( $state['document_version'] ?? '' )
			&& Search_Query_Normalizer::VERSION === (string) ( $state['normalizer_version'] ?? '' )
			&& Search_Section_Projector::VERSION === (string) ( $state['section_projection_version'] ?? '' );
	}

	/**
	 * @param array<string,mixed> $state
	 */
	public static function write_state( array $state ): bool {
		$status = sanitize_key( (string) ( $state['status'] ?? 'not_built' ) );
		if ( ! in_array( $status, array( 'not_built', 'building', 'ready', 'degraded', 'failed' ), true ) ) {
			return false;
		}

		$payload = array(
			'schema_version' => self::SCHEMA_VERSION,
			'status' => $status,
			'document_version' => Search_Document_Builder::VERSION,
			'normalizer_version' => Search_Query_Normalizer::VERSION,
			'section_projection_version' => Search_Section_Projector::VERSION,
			'corpus_count' => max( 0, (int) ( $state['corpus_count'] ?? 0 ) ),
			'source_fingerprint' => preg_replace( '/[^a-f0-9]/', '', strtolower( (string) ( $state['source_fingerprint'] ?? '' ) ) ) ?? '',
			'last_success_at_gmt' => (string) ( $state['last_success_at_gmt'] ?? '' ),
			'last_error_code' => sanitize_key( (string) ( $state['last_error_code'] ?? '' ) ),
		);

		return update_option( self::STATE_OPTION, $payload, false );
	}

	/**
	 * @param array<string,mixed> $document
	 * @return string|\WP_Error WRITTEN|NO_CHANGE
	 */
	public static function upsert( array $document ): string|\WP_Error {
		global $wpdb;

		try {
			$sections_json = Canonical_JSON::encode( is_array( $document['sections'] ?? null ) ? $document['sections'] : array() );
		} catch ( \JsonException $error ) {
			return new \WP_Error( 'search_projection_sections_encode_failed', 'Falha ao serializar Section Projection.' );
		}

		$data = array(
			'post_id' => (int) ( $document['post_id'] ?? 0 ),
			'document_state' => (string) ( $document['document_state'] ?? 'degraded' ),
			'source_kind' => (string) ( $document['source_kind'] ?? 'unknown' ),
			'title_norm' => (string) ( $document['title_norm'] ?? '' ),
			'summary_norm' => (string) ( $document['summary_norm'] ?? '' ),
			'headings_norm' => (string) ( $document['headings_norm'] ?? '' ),
			'taxonomy_norm' => (string) ( $document['taxonomy_norm'] ?? '' ),
			'body_norm' => (string) ( $document['body_norm'] ?? '' ),
			'sections_json' => $sections_json,
			'section_projection_version' => (string) ( $document['section_projection_version'] ?? Search_Section_Projector::VERSION ),
			'source_hash' => (string) ( $document['source_hash'] ?? '' ),
			'document_hash' => (string) ( $document['document_hash'] ?? '' ),
			'document_version' => (string) ( $document['document_version'] ?? '' ),
			'normalizer_version' => (string) ( $document['normalizer_version'] ?? '' ),
			'post_modified_gmt' => self::nullable_datetime( (string) ( $document['post_modified_gmt'] ?? '' ) ),
			'indexed_at_gmt' => (string) ( $document['indexed_at_gmt'] ?? '' ),
		);

		if ( $data['post_id'] <= 0 || ! preg_match( '/^[a-f0-9]{64}$/', $data['source_hash'] ) || ! preg_match( '/^[a-f0-9]{64}$/', $data['document_hash'] ) ) {
			return new \WP_Error( 'search_projection_invalid_document', 'Search Document inválido para persistência.' );
		}

		// phpcs:disable WordPress.DB.PreparedSQL.NotPrepared -- Internal table identifier derives only from the WordPress prefix; values remain placeholder-bound.
		$existing_sql = $wpdb->prepare(
			'SELECT source_hash, document_hash, document_version, normalizer_version, section_projection_version FROM ' . self::table_name() . ' WHERE post_id = %d LIMIT 1',
			$data['post_id']
		);
		$existing = $wpdb->get_row( $existing_sql, ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- Prepared immediately above.
		// phpcs:enable WordPress.DB.PreparedSQL.NotPrepared

		if ( '' !== (string) $wpdb->last_error ) {
			return new \WP_Error( 'search_projection_read_failed', 'Falha ao verificar Search Document existente.' );
		}

		if (
			is_array( $existing )
			&& $data['source_hash'] === (string) ( $existing['source_hash'] ?? '' )
			&& $data['document_hash'] === (string) ( $existing['document_hash'] ?? '' )
			&& $data['document_version'] === (string) ( $existing['document_version'] ?? '' )
			&& $data['normalizer_version'] === (string) ( $existing['normalizer_version'] ?? '' )
			&& $data['section_projection_version'] === (string) ( $existing['section_projection_version'] ?? '' )
		) {
			return self::UPSERT_NO_CHANGE;
		}

		$result = $wpdb->replace(
			self::table_name(),
			$data,
			array( '%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s' )
		);

		if ( false === $result ) {
			return new \WP_Error( 'search_projection_write_failed', 'Falha ao persistir Search Document.' );
		}

		return self::UPSERT_WRITTEN;
	}

	/**
	 * @param array<int,string> $tokens
	 * @return array<int,array<string,mixed>>|\WP_Error
	 */
	public static function retrieve_candidates( array $tokens, int $cap = self::CANDIDATE_CAP ): array|\WP_Error {
		global $wpdb;

		$tokens = array_values( array_unique( array_filter( array_map( 'strval', $tokens ) ) ) );
		$cap = max( 1, min( self::CANDIDATE_CAP, $cap ) );

		if ( empty( $tokens ) ) {
			return array();
		}
		if ( ! self::is_ready() ) {
			return new \WP_Error( 'search_projection_not_ready', 'Search Projection não está pronta.', array( 'status' => 503 ) );
		}

		$strict = self::query_candidates( $tokens, $cap, true, array() );
		if ( $strict instanceof \WP_Error ) {
			return $strict;
		}
		if ( count( $strict ) >= $cap ) {
			return array_slice( $strict, 0, $cap );
		}

		$strict_ids = array_values( array_map( static fn ( array $row ): int => (int) $row['post_id'], $strict ) );
		$relaxed = self::query_candidates( $tokens, $cap - count( $strict ), false, $strict_ids );
		if ( $relaxed instanceof \WP_Error ) {
			return $relaxed;
		}

		return array_merge( $strict, $relaxed );
	}

	/**
	 * @param array<int,string> $tokens
	 * @param array<int,int> $exclude_ids
	 * @return array<int,array<string,mixed>>|\WP_Error
	 */
	private static function query_candidates( array $tokens, int $limit, bool $strict, array $exclude_ids ): array|\WP_Error {
		global $wpdb;

		$token_groups = array();
		$args = array();

		foreach ( $tokens as $token ) {
			// Campos da Projection já são normalizados para tokens separados por espaço.
			// A borda artificial evita "estrutura" casar "infraestrutura" antes do ranker.
			$like = '%' . $wpdb->esc_like( ' ' . $token . ' ' ) . '%';
			$parts = array();
			foreach ( self::SEARCH_FIELDS as $field ) {
				$parts[] = "CONCAT(' ', {$field}, ' ') LIKE %s";
				$args[] = $like;
			}
			$token_groups[] = '(' . implode( ' OR ', $parts ) . ')';
		}

		$where = implode( $strict ? ' AND ' : ' OR ', $token_groups );

		if ( ! empty( $exclude_ids ) ) {
			$placeholders = implode( ',', array_fill( 0, count( $exclude_ids ), '%d' ) );
			$where = '(' . $where . ") AND post_id NOT IN ({$placeholders})";
			foreach ( $exclude_ids as $post_id ) {
				$args[] = $post_id;
			}
		}

		$args[] = $limit;
		$table = self::table_name();
		$sql = "SELECT post_id, document_state, source_kind, title_norm, summary_norm, headings_norm, taxonomy_norm, body_norm
			FROM {$table}
			WHERE {$where}
			ORDER BY post_id ASC
			LIMIT %d";

		// phpcs:disable WordPress.DB.PreparedSQL.NotPrepared,PluginCheck.Security.DirectDB.UnescapedDBParameter -- SQL shape is built only from fixed internal field names/table name; every user token/limit is placeholder-bound.
		$prepared = $wpdb->prepare( $sql, ...$args );
		$rows = $wpdb->get_results( $prepared, ARRAY_A );
		// phpcs:enable WordPress.DB.PreparedSQL.NotPrepared,PluginCheck.Security.DirectDB.UnescapedDBParameter

		if ( '' !== (string) $wpdb->last_error ) {
			return new \WP_Error( 'search_projection_read_failed', 'Falha ao consultar Search Projection.' );
		}

		return is_array( $rows ) ? $rows : array();
	}

	/**
	 * Carrega Section Projection somente para parents já ranqueados.
	 *
	 * @param array<int,int> $post_ids
	 * @return array<int,array<int,array<string,mixed>>>|\WP_Error
	 */
	public static function sections_for_posts( array $post_ids ): array|\WP_Error {
		global $wpdb;

		$post_ids = array_values(
			array_unique(
				array_filter(
					array_map( 'intval', $post_ids ),
					static fn ( int $post_id ): bool => $post_id > 0
				)
			)
		);
		$post_ids = array_slice( $post_ids, 0, self::SECTION_PARENT_CAP );

		if ( empty( $post_ids ) ) {
			return array();
		}
		if ( ! self::is_ready() ) {
			return new \WP_Error( 'search_projection_not_ready', 'Search Projection não está pronta.', array( 'status' => 503 ) );
		}

		$placeholders = implode( ',', array_fill( 0, count( $post_ids ), '%d' ) );
		// phpcs:disable WordPress.DB.PreparedSQL.NotPrepared,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- Placeholder list is generated internally from validated integer IDs; table identifier is internal.
		$sql = $wpdb->prepare(
			'SELECT post_id, sections_json, section_projection_version FROM ' . self::table_name() . " WHERE post_id IN ({$placeholders}) ORDER BY post_id ASC",
			...$post_ids
		);
		$rows = $wpdb->get_results( $sql, ARRAY_A );
		// phpcs:enable WordPress.DB.PreparedSQL.NotPrepared,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare

		if ( '' !== (string) $wpdb->last_error ) {
			return new \WP_Error( 'search_projection_sections_read_failed', 'Falha ao consultar Section Projection.' );
		}

		$out = array_fill_keys( $post_ids, array() );
		foreach ( is_array( $rows ) ? $rows : array() as $row ) {
			$post_id = (int) ( $row['post_id'] ?? 0 );
			if ( ! isset( $out[ $post_id ] ) ) {
				continue;
			}
			if ( Search_Section_Projector::VERSION !== (string) ( $row['section_projection_version'] ?? '' ) ) {
				return new \WP_Error( 'search_projection_sections_version_mismatch', 'Section Projection está stale.' );
			}

			$json = (string) ( $row['sections_json'] ?? '[]' );
			try {
				$sections = json_decode( $json, true, 512, JSON_THROW_ON_ERROR );
			} catch ( \JsonException $error ) {
				return new \WP_Error( 'search_projection_sections_decode_failed', 'Section Projection inválida.' );
			}

			if ( ! is_array( $sections ) ) {
				return new \WP_Error( 'search_projection_sections_invalid', 'Section Projection possui formato inválido.' );
			}
			$out[ $post_id ] = array_slice( array_values( $sections ), 0, Search_Section_Projector::MAX_SECTIONS );
		}

		return $out;
	}

	/**
	 * Verifica a estrutura física sem colocar SHOW em hot path de Search.
	 *
	 * @return array<string,mixed>|\WP_Error
	 */
	public static function schema_contract(): array|\WP_Error {
		global $wpdb;

		if ( ! self::schema_exists() ) {
			return new \WP_Error( 'search_projection_schema_missing', 'Tabela da Search Projection não existe.' );
		}

		$table = self::table_name();
		$column_rows = $wpdb->get_results( 'SHOW COLUMNS FROM ' . $table, ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- Internal table identifier only.
		if ( '' !== (string) $wpdb->last_error ) {
			return new \WP_Error( 'search_projection_schema_columns_failed', 'Falha ao inspecionar colunas da Search Projection.' );
		}

		$actual_columns = array();
		foreach ( is_array( $column_rows ) ? $column_rows : array() as $row ) {
			$field = (string) ( $row['Field'] ?? '' );
			if ( '' !== $field ) {
				$actual_columns[] = $field;
			}
		}

		$index_rows = $wpdb->get_results( 'SHOW INDEX FROM ' . $table, ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- Internal table identifier only.
		if ( '' !== (string) $wpdb->last_error ) {
			return new \WP_Error( 'search_projection_schema_indexes_failed', 'Falha ao inspecionar índices da Search Projection.' );
		}

		$actual_indexes = array();
		foreach ( is_array( $index_rows ) ? $index_rows : array() as $row ) {
			$name = (string) ( $row['Key_name'] ?? '' );
			if ( '' !== $name ) {
				$actual_indexes[ $name ] = true;
			}
		}
		$actual_indexes = array_keys( $actual_indexes );
		sort( $actual_indexes, SORT_STRING );

		$missing_columns = array_values( array_diff( self::REQUIRED_COLUMNS, $actual_columns ) );
		$missing_indexes = array_values( array_diff( self::REQUIRED_INDEXES, $actual_indexes ) );

		return array(
			'schema_version' => self::SCHEMA_VERSION,
			'required_columns' => self::REQUIRED_COLUMNS,
			'actual_columns' => $actual_columns,
			'missing_columns' => $missing_columns,
			'required_indexes' => self::REQUIRED_INDEXES,
			'actual_indexes' => $actual_indexes,
			'missing_indexes' => $missing_indexes,
			'pass' => empty( $missing_columns ) && empty( $missing_indexes ),
		);
	}

	public static function schema_exists(): bool {
		global $wpdb;

		$table = self::table_name();
		$sql = $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $table ) );
		$found = $wpdb->get_var( $sql );

		return is_string( $found ) && $table === $found;
	}

	/**
	 * @return int|\WP_Error
	 */
	public static function count_rows(): int|\WP_Error {
		global $wpdb;

		$count = $wpdb->get_var( 'SELECT COUNT(*) FROM ' . self::table_name() ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- Internal table identifier only.
		if ( '' !== (string) $wpdb->last_error ) {
			return new \WP_Error( 'search_projection_count_failed', 'Falha ao contar Search Documents.' );
		}

		return max( 0, (int) $count );
	}

	/**
	 * @return array<int,array{post_id:int,source_hash:string,document_hash:string,document_state:string,source_kind:string}>|\WP_Error
	 */
	public static function hash_snapshot(): array|\WP_Error {
		global $wpdb;

		$rows = $wpdb->get_results(
			'SELECT post_id, source_hash, document_hash, document_state, source_kind FROM ' . self::table_name() . ' ORDER BY post_id ASC', // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- Internal table identifier only.
			ARRAY_A
		);

		if ( '' !== (string) $wpdb->last_error ) {
			return new \WP_Error( 'search_projection_snapshot_failed', 'Falha ao ler snapshot da Search Projection.' );
		}

		$out = array();
		foreach ( is_array( $rows ) ? $rows : array() as $row ) {
			$out[] = array(
				'post_id' => (int) ( $row['post_id'] ?? 0 ),
				'source_hash' => (string) ( $row['source_hash'] ?? '' ),
				'document_hash' => (string) ( $row['document_hash'] ?? '' ),
				'document_state' => (string) ( $row['document_state'] ?? '' ),
				'source_kind' => (string) ( $row['source_kind'] ?? '' ),
			);
		}
		return $out;
	}

	/**
	 * Remove somente rows que não pertencem ao corpus canônico atual.
	 * Chamada autorizada apenas após uma passagem completa bem-sucedida.
	 *
	 * @param array<int,int> $valid_post_ids
	 * @return int|\WP_Error
	 */
	public static function delete_stale_rows( array $valid_post_ids ): int|\WP_Error {
		global $wpdb;

		$valid_post_ids = array_values(
			array_unique(
				array_filter(
					array_map( 'intval', $valid_post_ids ),
					static fn ( int $post_id ): bool => $post_id > 0
				)
			)
		);

		if ( empty( $valid_post_ids ) ) {
			return new \WP_Error(
				'search_projection_empty_corpus_cleanup_blocked',
				'Limpeza stale bloqueada para corpus vazio.'
			);
		}

		$placeholders = implode( ',', array_fill( 0, count( $valid_post_ids ), '%d' ) );
		// phpcs:disable WordPress.DB.PreparedSQL.NotPrepared,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- Placeholder list is generated internally from validated integer IDs; table identifier is internal.
		$sql = $wpdb->prepare(
			'DELETE FROM ' . self::table_name() . " WHERE post_id NOT IN ({$placeholders})",
			...$valid_post_ids
		);
		$result = $wpdb->query( $sql );
		// phpcs:enable WordPress.DB.PreparedSQL.NotPrepared,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare

		if ( false === $result || '' !== (string) $wpdb->last_error ) {
			return new \WP_Error( 'search_projection_stale_cleanup_failed', 'Falha ao remover Search Documents stale.' );
		}

		return max( 0, (int) $result );
	}

	private static function nullable_datetime( string $value ): ?string {
		$value = trim( $value );
		return '' === $value || '0000-00-00 00:00:00' === $value ? null : $value;
	}
}
