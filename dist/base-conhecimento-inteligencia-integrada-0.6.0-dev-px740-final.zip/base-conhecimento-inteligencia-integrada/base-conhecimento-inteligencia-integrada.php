<?php
/**
 * Plugin Name: Base de Conhecimento com Inteligência Integrada
 * Description: Base de Conhecimento com sumário, classificação, revisão, governança, estrutura editorial e recursos de inteligência integrados.
 * Plugin URI: https://github.com/R-RERISON/Base-de-conhecimento-com-intelig-ncia-integrada
 * Version: 0.6.0-dev
 * Requires at least: 6.6
 * Requires PHP: 8.1
 * Author: BDC
 * License: GPL-2.0-or-later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Update URI: https://github.com/R-RERISON/Base-de-conhecimento-com-intelig-ncia-integrada
 * Text Domain: base-conhecimento-inteligencia-integrada
 *
 * @package BDC_Knowledge_Base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'BDC_KB_VERSION', '0.6.0-dev' );
define( 'BDC_KB_SPEC004_G245_T100A_POST_WORKSPACE_BUILD', true );
define( 'BDC_KB_SPEC004_G245_T100C_CORE_BLOCKS_ACTIVITY_BUILD', true );
define( 'BDC_KB_SPEC005_G530_SEARCH_ENGINE_BUILD', true );
define( 'BDC_KB_PUBLIC_EXPERIENCE_PREVIEW_BUILD', true );
define( 'BDC_KB_WORD_CLOUD_BUILD', true );
if ( ! defined( 'BDC_KB_SEARCH_ENABLED' ) ) {
	define( 'BDC_KB_SEARCH_ENABLED', true );
}
if ( ! defined( 'BDC_KB_ELEMENTOR_WRITER_ENABLED' ) ) {
	define( 'BDC_KB_ELEMENTOR_WRITER_ENABLED', false );
}
define( 'BDC_KB_FILE', __FILE__ );
define( 'BDC_KB_DIR', plugin_dir_path( __FILE__ ) );
define( 'BDC_KB_URL', plugin_dir_url( __FILE__ ) );

require_once BDC_KB_DIR . 'includes/class-core-runtime-loader.php';
require_once BDC_KB_DIR . 'includes/class-runtime-module-registry.php';
require_once BDC_KB_DIR . 'includes/class-plugin.php';

\BDC\KnowledgeBase\Core_Runtime_Loader::load();
\BDC\KnowledgeBase\Runtime_Module_Registry::load( 'word_cloud' );

\BDC\KnowledgeBase\Runtime_Module_Registry::load( 'search' );
\BDC\KnowledgeBase\Runtime_Module_Registry::load( 'public_experience_preview' );

\BDC\KnowledgeBase\Plugin::register();
\BDC\KnowledgeBase\Visual_Foundation::register();
\BDC\KnowledgeBase\Runtime_Module_Registry::register( 'word_cloud' );
\BDC\KnowledgeBase\Runtime_Module_Registry::register( 'search' );
\BDC\KnowledgeBase\Runtime_Module_Registry::register( 'public_experience_preview' );
