<?php
/**
 * Non-disruptive public experience preview orchestration.
 *
 * @package BDC_Knowledge_Base
 */

namespace BDC\KnowledgeBase;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Public_Experience {

	public const SHELL_VERSION = 'public-shell-v1.0.0';
	public const PAGE_SLUG = 'bdc-kb-public-experience-preview';
	private const QUERY_KEY = 'bdc_kb_preview';
	private const NONCE_KEY = 'bdc_kb_preview_nonce';
	private const GLOBAL_QUERY_KEY = 'bdc_global_q';
	private const ISOLATION_KEY = 'bdc_kb_isolation';
	private const LEGACY_HOME_SHORTCODES = array( 'bc_home_config', 'bc_ultimas', 'bc_populares' );

	/** @var array<int,int> */
	private const ARTICLE_SAMPLES = array( 396, 367, 36431, 515, 358 );

	public static function register(): void {
		add_action( 'admin_menu', array( self::class, 'register_admin_page' ), 55 );
		add_action( 'admin_enqueue_scripts', array( self::class, 'enqueue_admin_assets' ), 60 );
		add_filter( 'template_include', array( self::class, 'template_include' ), 99 );
		add_action( 'template_redirect', array( self::class, 'prepare_preview_request' ), 1 );
		add_action( 'wp_enqueue_scripts', array( self::class, 'enqueue_assets' ), 40 );
		add_action( 'wp_enqueue_scripts', array( self::class, 'apply_isolation_assets' ), 999 );
		add_filter( 'body_class', array( self::class, 'body_class' ) );
		add_action( 'wp_ajax_bdc_kb_public_search_preview', array( self::class, 'ajax_search_preview' ) );
	}

	public static function register_admin_page(): void {
		add_submenu_page( Admin_Page::PAGE_SLUG, 'Prévia da Experiência Pública', 'Prévia Pública', 'manage_options', self::PAGE_SLUG, array( self::class, 'render_admin_page' ) );
	}

	public static function enqueue_admin_assets( string $hook_suffix ): void {
		if ( 'base-de-conhecimento_page_' . self::PAGE_SLUG !== $hook_suffix ) {
			return;
		}
		wp_enqueue_style( 'bdc-kb-public-preview-admin', BDC_KB_URL . 'assets/css/visual-foundation.css', array(), BDC_KB_VERSION );
		wp_enqueue_style( 'dashicons' );
	}

	public static function render_admin_page(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Permissão insuficiente.', 'base-conhecimento-inteligencia-integrada' ), '', array( 'response' => 403 ) );
		}
		echo '<div class="wrap bdc-kb-admin bdc-kb-admin--public-preview">';
		echo '<section class="bdc-kb-preview-hero"><div><p class="bdc-kb-preview-hero__eyebrow">Base de Conhecimento</p><h1>' . esc_html__( 'Prévia da Experiência Pública', 'base-conhecimento-inteligencia-integrada' ) . '</h1><p>' . esc_html__( 'Homologação visual do Home Search-first e do Article Reader antes do cutover público.', 'base-conhecimento-inteligencia-integrada' ) . '</p></div><span class="bdc-kb-preview-state">Homologação ativa</span></section>';
		echo '<div class="bdc-kb-preview-guardrail"><span class="dashicons dashicons-shield" aria-hidden="true"></span><span><strong>Sem cutover:</strong> page_on_front, post_content, _elementor_data, ASI, GRE, GAC, WPUI e Astra permanecem inalterados.</span></div>';
		echo '<div class="bdc-kb-overview-grid bdc-kb-preview-grid">';
		echo '<section class="bdc-kb-overview-card"><span class="bdc-kb-card-icon"><span class="dashicons dashicons-search" aria-hidden="true"></span></span><h4>Home Search-first</h4><p>Home minimalista, busca como ação principal e navegação secundária sob demanda.</p><a class="button button-primary bdc-kb-button-with-icon" target="_blank" rel="noopener" href="' . esc_url( self::home_preview_url() ) . '"><span class="dashicons dashicons-visibility" aria-hidden="true"></span><span>Abrir Home</span></a></section>';
		echo '<section class="bdc-kb-overview-card"><span class="bdc-kb-card-icon"><span class="dashicons dashicons-media-document" aria-hidden="true"></span></span><h4>Article Reader</h4><p>Leitura limpa com busca persistente, Dicas úteis, Resumo Executivo e pipeline legado preservado.</p><div class="bdc-kb-vocabulary-actions">';
		foreach ( self::ARTICLE_SAMPLES as $post_id ) {
			$post = get_post( $post_id );
			if ( ! is_object( $post ) || 'post' !== (string) ( $post->post_type ?? '' ) || 'publish' !== (string) ( $post->post_status ?? '' ) ) { continue; }
			echo '<a class="bdc-kb-vocabulary-action" target="_blank" rel="noopener" href="' . esc_url( self::article_preview_url( $post_id ) ) . '"><span class="dashicons dashicons-external" aria-hidden="true"></span><span>#' . esc_html( (string) $post_id ) . ' — ' . esc_html( wp_trim_words( (string) $post->post_title, 7 ) ) . '</span></a>';
		}
		echo '</div></section>';
		echo '<section class="bdc-kb-overview-card"><span class="bdc-kb-card-icon"><span class="dashicons dashicons-shield-alt" aria-hidden="true"></span></span><h4>PX-750 — Isolamento</h4><p>Valida a experiência candidata sem estilos do tema, Custom CSS e shortcodes legados da Home, somente nesta requisição.</p><div class="bdc-kb-vocabulary-actions">';
		echo '<a class="button button-secondary bdc-kb-button-with-icon" target="_blank" rel="noopener" href="' . esc_url( self::home_preview_url( 0, '', true ) ) . '"><span class="dashicons dashicons-admin-home" aria-hidden="true"></span><span>Home isolada</span></a>';
		$sample_id = self::ARTICLE_SAMPLES[0] ?? 0;
		if ( $sample_id > 0 ) {
			echo '<a class="button button-secondary bdc-kb-button-with-icon" target="_blank" rel="noopener" href="' . esc_url( self::article_preview_url( $sample_id, '', true ) ) . '"><span class="dashicons dashicons-media-document" aria-hidden="true"></span><span>Reader isolado</span></a>';
		}
		echo '</div></section></div>';
		echo '</div>';
	}

	public static function home_preview_url( int $category_id = 0, string $query = '', ?bool $isolated = null ): string {
		$front_id = absint( get_option( 'page_on_front', 0 ) );
		$url = $front_id > 0 ? get_permalink( $front_id ) : home_url( '/' );
		if ( ! is_string( $url ) || '' === $url ) { $url = home_url( '/' ); }
		$args = array( self::QUERY_KEY => 'home', self::NONCE_KEY => wp_create_nonce( 'bdc_kb_public_preview_home' ) );
		if ( null === $isolated ) { $isolated = self::is_isolation_mode(); }
		if ( $isolated ) { $args[ self::ISOLATION_KEY ] = '1'; }
		if ( $category_id > 0 ) { $args['bdc_category'] = $category_id; }
		if ( '' !== trim( $query ) ) { $args[ self::GLOBAL_QUERY_KEY ] = trim( $query ); }
		return add_query_arg( $args, $url );
	}

	public static function article_preview_url( int $post_id, string $query = '', ?bool $isolated = null ): string {
		$url = get_permalink( $post_id );
		if ( ! is_string( $url ) || '' === $url ) { $url = home_url( '/' ); }
		$args = array( self::QUERY_KEY => 'article', self::NONCE_KEY => wp_create_nonce( 'bdc_kb_public_preview_article' ) );
		if ( null === $isolated ) { $isolated = self::is_isolation_mode(); }
		if ( $isolated ) { $args[ self::ISOLATION_KEY ] = '1'; }
		if ( '' !== trim( $query ) ) { $args[ self::GLOBAL_QUERY_KEY ] = trim( $query ); }
		return add_query_arg( $args, $url );
	}

	public static function template_include( string $template ): string {
		$kind = self::preview_kind();
		if ( 'home' === $kind ) {
			$candidate = BDC_KB_DIR . 'templates/public-home-preview.php';
			return is_file( $candidate ) ? $candidate : $template;
		}
		if ( 'article' === $kind && is_singular( 'post' ) ) {
			$candidate = BDC_KB_DIR . 'templates/public-article-preview.php';
			return is_file( $candidate ) ? $candidate : $template;
		}
		return $template;
	}

	public static function prepare_preview_request(): void {
		$kind = self::preview_kind();
		if ( null === $kind ) { return; }
		nocache_headers();

		if ( self::is_isolation_mode() ) {
			remove_action( 'wp_head', 'wp_custom_css_cb', 101 );
			foreach ( self::LEGACY_HOME_SHORTCODES as $shortcode ) {
				remove_shortcode( $shortcode );
			}
		}

		if ( 'article' !== $kind ) { return; }
		remove_filter( 'the_content', array( 'BDC\\ExecutiveSummary\\Helpful_Tips_Renderer', 'prepend_to_content' ), 15 );
		remove_filter( 'the_content', array( 'BDC\\ExecutiveSummary\\Frontend_Renderer', 'append_side_panel' ), 30 );
		remove_action( 'wp_footer', array( 'BDC\\ExecutiveSummary\\Frontend_Renderer', 'render_side_panel' ) );
	}

	public static function apply_isolation_assets(): void {
		if ( ! self::is_isolation_mode() ) { return; }

		$theme_uris = array_filter(
			array(
				untrailingslashit( get_template_directory_uri() ),
				untrailingslashit( get_stylesheet_directory_uri() ),
			)
		);

		global $wp_styles;
		if ( $wp_styles instanceof \WP_Styles ) {
			foreach ( (array) $wp_styles->queue as $handle ) {
				$registered = $wp_styles->registered[ $handle ] ?? null;
				$src = is_object( $registered ) ? (string) ( $registered->src ?? '' ) : '';
				if ( self::is_theme_asset_source( $src, $theme_uris ) ) {
					wp_dequeue_style( (string) $handle );
				}
			}
		}

		global $wp_scripts;
		if ( $wp_scripts instanceof \WP_Scripts ) {
			foreach ( (array) $wp_scripts->queue as $handle ) {
				$registered = $wp_scripts->registered[ $handle ] ?? null;
				$src = is_object( $registered ) ? (string) ( $registered->src ?? '' ) : '';
				if ( self::is_theme_asset_source( $src, $theme_uris ) ) {
					wp_dequeue_script( (string) $handle );
				}
			}
		}
	}

	public static function enqueue_assets(): void {
		$kind = self::preview_kind();
		if ( null === $kind ) { return; }
		Public_Auth_Bridge::prime();
		wp_enqueue_style( 'dashicons' );
		wp_enqueue_style( 'bdc-kb-public-foundation', BDC_KB_URL . 'assets/css/public-foundation.css', array(), BDC_KB_VERSION );
		wp_enqueue_style( 'bdc-kb-public-header', BDC_KB_URL . 'assets/css/public-header.css', array( 'bdc-kb-public-foundation' ), BDC_KB_VERSION );
		wp_enqueue_style( 'bdc-kb-public-' . $kind, BDC_KB_URL . 'assets/css/public-' . $kind . '.css', array( 'bdc-kb-public-header' ), BDC_KB_VERSION );
		wp_enqueue_script( 'bdc-kb-public-search', BDC_KB_URL . 'assets/js/public-search.js', array(), BDC_KB_VERSION, true );
		if ( 'article' === $kind ) {
			wp_enqueue_script( 'bdc-kb-public-reader', BDC_KB_URL . 'assets/js/public-reader.js', array(), BDC_KB_VERSION, true );
		}
		wp_localize_script(
			'bdc-kb-public-search',
			'BDC_KB_PUBLIC_SEARCH',
			array(
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				'action' => Public_Search_Facade::AJAX_ACTION,
				'nonce' => wp_create_nonce( Public_Search_Facade::NONCE_ACTION ),
				'previewMode' => true,
				'isolationMode' => self::is_isolation_mode(),
				'minChars' => Public_Search_Facade::MIN_QUERY_LENGTH,
				'debounceMs' => 180,
				'uiVersion' => 'premium-v7',
				'shellVersion' => self::SHELL_VERSION,
				'consultAction' => class_exists( Word_Cloud_Consultations::class ) ? Word_Cloud_Consultations::AJAX_ACTION : '',
				'consultNonce' => class_exists( Word_Cloud_Consultations::class ) ? wp_create_nonce( Word_Cloud_Consultations::NONCE_ACTION ) : '',
			)
		);
	}

	/** @param array<int,string> $classes @return array<int,string> */
	public static function body_class( array $classes ): array {
		$kind = self::preview_kind();
		if ( null === $kind ) { return $classes; }
		$classes[] = 'bdc-public-preview';
		$classes[] = 'bdc-public-preview--' . $kind;
		$classes[] = 'bdc-' . sanitize_html_class( str_replace( '.', '-', self::SHELL_VERSION ) );
		if ( self::is_isolation_mode() ) { $classes[] = 'bdc-public-isolation'; }
		return $classes;
	}

	/** @return array<int,array{label:string,url:string,icon:string,external:bool}> */
	public static function quick_links(): array {
		return array(
			array( 'label' => 'Página Inicial', 'url' => self::home_preview_url(), 'icon' => 'dashicons-admin-home', 'external' => false ),
			array( 'label' => 'Consulta Avançada', 'url' => home_url( '/consulta-avancada/' ), 'icon' => 'dashicons-media-document', 'external' => false ),
			array( 'label' => 'Telefones', 'url' => home_url( '/telefones-importantes/' ), 'icon' => 'dashicons-phone', 'external' => false ),
			array( 'label' => 'Links Úteis', 'url' => home_url( '/links-uteis/' ), 'icon' => 'dashicons-admin-links', 'external' => false ),
			array( 'label' => 'POSTI', 'url' => 'https://vok-smb2.cloud-p.bcnet.bcb.gov.br/app/manual/posti/publico', 'icon' => 'dashicons-external', 'external' => true ),
		);
	}

	public static function render_skip_link(): void {
		echo '<a class="bdc-public-skip-link" href="#bdc-public-main">' . esc_html__( 'Pular para o conteúdo', 'base-conhecimento-inteligencia-integrada' ) . '</a>';
	}

	public static function render_header(): void {
		$kind = self::preview_kind() ?? 'home';
		$links = self::quick_links();

		echo '<header class="bdc-public-header" data-bdc-header><div class="bdc-public-header__inner">';
		echo '<a class="bdc-public-brand" href="' . esc_url( self::home_preview_url() ) . '" aria-label="Página inicial da Base de Conhecimento">';
		self::render_brand_visual();
		echo '<span class="bdc-public-brand__copy"><strong>Base de Conhecimento</strong><small>Central de apoio operacional</small></span></a>';

		echo '<nav id="bdc-public-quicknav" class="bdc-public-quicknav" aria-label="Links rápidos"><span class="bdc-public-quicknav__label">Links rápidos</span><div class="bdc-public-quicknav__links">';
		foreach ( $links as $item ) {
			$external = ! empty( $item['external'] );
			echo '<a class="bdc-public-quicknav__link' . ( $external ? ' is-external' : '' ) . '" href="' . esc_url( (string) $item['url'] ) . '"' . ( $external ? ' target="_blank" rel="noopener noreferrer"' : '' ) . '>';
			echo '<span class="dashicons ' . esc_attr( (string) $item['icon'] ) . '" aria-hidden="true"></span><span>' . esc_html( (string) $item['label'] ) . '</span></a>';
		}
		echo '</div></nav>';

		echo '<div class="bdc-public-header__profile">';
		Public_Auth_Bridge::render();
		echo '</div>';
		echo '<button class="bdc-public-header__toggle" type="button" data-bdc-header-toggle aria-controls="bdc-public-quicknav" aria-label="Abrir links rápidos" aria-expanded="false"><span></span><span></span><span></span></button>';
		echo '</div>';

		if ( 'article' === $kind ) {
			echo '<div class="bdc-public-header__searchrow"><div class="bdc-public-header__searchinner">';
			self::render_global_search( true );
			echo '</div></div>';
			self::render_global_search_results();
		}
		echo '</header>';
	}

	public static function render_global_search( bool $compact = false ): void {
		$query = self::global_query();
		$kind = self::preview_kind() ?? 'home';
		$post_id = 'article' === $kind ? (int) get_queried_object_id() : 0;
		$action = 'article' === $kind && $post_id > 0 ? get_permalink( $post_id ) : get_permalink( absint( get_option( 'page_on_front', 0 ) ) );
		if ( ! is_string( $action ) || '' === $action ) { $action = home_url( '/' ); }
		echo '<form class="bdc-global-search' . ( $compact ? ' bdc-global-search--compact' : '' ) . '" method="get" action="' . esc_url( $action ) . '" role="search" data-bdc-live-search-form data-bdc-search-context="article">';
		echo '<input type="hidden" name="' . esc_attr( self::QUERY_KEY ) . '" value="' . esc_attr( $kind ) . '">';
		echo '<input type="hidden" name="' . esc_attr( self::NONCE_KEY ) . '" value="' . esc_attr( wp_create_nonce( 'bdc_kb_public_preview_' . $kind ) ) . '">';
		if ( self::is_isolation_mode() ) { echo '<input type="hidden" name="' . esc_attr( self::ISOLATION_KEY ) . '" value="1">'; }
		echo '<span class="dashicons dashicons-search" aria-hidden="true"></span>';
		echo '<label class="screen-reader-text" for="bdc-global-search-input">Buscar na Base de Conhecimento</label>';
		echo '<input id="bdc-global-search-input" data-bdc-global-search data-bdc-live-search-input type="search" name="' . esc_attr( self::GLOBAL_QUERY_KEY ) . '" value="' . esc_attr( $query ) . '" placeholder="Buscar na Base de Conhecimento">';
		echo '<kbd>Ctrl K</kbd><button type="submit" aria-label="Pesquisar"><span class="dashicons dashicons-arrow-right-alt2" aria-hidden="true"></span></button></form>';
	}

	public static function global_search_results(): ?array {
		$query = self::global_query();
		return '' === $query ? null : Public_Home_Read_Model::preview_search( $query );
	}

	public static function render_search_results( ?array $search, string $class = 'bdc-search-results' ): void {
		if ( ! is_array( $search ) ) { return; }
		$results = (array) ( $search['results'] ?? array() );
		$state = sanitize_key( (string) ( $search['state'] ?? '' ) );
		echo '<div class="' . esc_attr( $class ) . '" aria-live="polite">';
		if ( empty( $results ) ) {
			if ( in_array( $state, array( 'invalid_query', 'technical_error', 'rate_limited', 'request_error' ), true ) ) {
				$message = trim( (string) ( $search['message'] ?? '' ) );
				if ( '' === $message ) {
					$message = 'Não foi possível concluir a pesquisa agora.';
				}
				echo '<div class="bdc-search-error" role="status"><strong>' . esc_html( $message ) . '</strong><span>Tente novamente ou ajuste a consulta.</span></div></div>';
				return;
			}
			echo '<div class="bdc-search-empty">Nenhum resultado encontrado.</div></div>';
			return;
		}
		foreach ( $results as $result ) {
			$post_id = (int) ( $result['post_id'] ?? 0 );
			$post = $post_id > 0 ? get_post( $post_id ) : null;
			if ( ! is_object( $post ) ) { continue; }
			$categories = get_the_category( $post_id );
			$category = ! empty( $categories ) && is_object( $categories[0] ) ? (string) $categories[0]->name : 'Instrução';
			$raw_excerpt = '' !== trim( (string) $post->post_excerpt ) ? (string) $post->post_excerpt : (string) $post->post_content;
			$excerpt = wp_trim_words( wp_strip_all_tags( strip_shortcodes( $raw_excerpt ) ), 22, '…' );
			echo '<a class="bdc-live-result bdc-live-result--server" data-bdc-consult-term="' . esc_attr( (string) ( $result['title'] ?? '' ) ) . '" data-bdc-consult-source="result_click" href="' . esc_url( self::article_preview_url( $post_id ) ) . '">';
			echo '<span class="bdc-live-result__rank">' . esc_html( (string) ( $result['rank'] ?? '' ) ) . '</span>';
			echo '<span class="bdc-live-result__copy"><span class="bdc-live-result__meta">' . esc_html( $category ) . '</span><strong>' . esc_html( (string) ( $result['title'] ?? '' ) ) . '</strong>';
			if ( '' !== $excerpt ) { echo '<p>' . esc_html( $excerpt ) . '</p>'; }
			echo '</span><span class="dashicons dashicons-arrow-right-alt2" aria-hidden="true"></span></a>';
		}
		echo '</div>';
	}

	private static function render_global_search_results(): void {
		$search = self::global_search_results();
		echo '<div class="bdc-global-search-panel" data-bdc-live-search-panel';
		if ( ! is_array( $search ) ) {
			echo ' hidden';
		}
		echo '><div class="bdc-global-search-panel__inner">';
		echo '<div class="bdc-global-search-panel__head"><strong data-bdc-live-search-title>Resultados</strong><a href="' . esc_url( self::article_preview_url( (int) get_queried_object_id() ) ) . '" data-bdc-live-search-clear>Limpar</a></div>';
		echo '<div data-bdc-live-search-results aria-live="polite" aria-busy="false">';
		if ( is_array( $search ) ) {
			self::render_search_results( $search, 'bdc-search-results bdc-search-results--header' );
		}
		echo '</div></div></div>';
	}

	public static function ajax_search_preview(): void {
		check_ajax_referer( 'bdc_kb_public_search_preview', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => 'Permissão insuficiente.' ), 403 );
		}

		$isolated = isset( $_POST['isolation'] ) && '1' === sanitize_text_field( wp_unslash( (string) $_POST['isolation'] ) );

		$query = isset( $_POST['query'] ) && is_scalar( $_POST['query'] )
			? sanitize_text_field( wp_unslash( (string) $_POST['query'] ) )
			: '';
		$query = trim( $query );
		$length = function_exists( 'mb_strlen' ) ? mb_strlen( $query ) : strlen( $query );
		if ( $length < 2 ) {
			wp_send_json_success( array( 'query' => $query, 'count' => 0, 'results' => array(), 'state' => 'min_chars' ) );
		}

		$search = Public_Home_Read_Model::preview_search( $query );
		$rows = array();
		foreach ( (array) ( is_array( $search ) ? ( $search['results'] ?? array() ) : array() ) as $result ) {
			$post_id = (int) ( $result['post_id'] ?? 0 );
			$post = $post_id > 0 ? get_post( $post_id ) : null;
			if ( ! is_object( $post ) || 'publish' !== (string) ( $post->post_status ?? '' ) ) {
				continue;
			}
			$categories = get_the_category( $post_id );
			$category = ! empty( $categories ) && is_object( $categories[0] ) ? (string) $categories[0]->name : '';
			$raw_excerpt = '' !== trim( (string) $post->post_excerpt ) ? (string) $post->post_excerpt : (string) $post->post_content;
			$rows[] = array(
				'postId' => $post_id,
				'title' => (string) $post->post_title,
				'category' => $category,
				'excerpt' => wp_trim_words( wp_strip_all_tags( strip_shortcodes( $raw_excerpt ) ), 22, '…' ),
				'url' => self::article_preview_url( $post_id, '', $isolated ),
				'rank' => (int) ( $result['rank'] ?? 0 ),
			);
		}

		wp_send_json_success(
			array(
				'query' => $query,
				'count' => count( $rows ),
				'results' => $rows,
				'state' => empty( $rows ) ? 'empty' : 'ready',
			)
		);
	}

	public static function render_preview_banner( string $label ): void {
		$suffix = self::is_isolation_mode() ? ' · isolamento PX-750' : '';
		echo '<div class="bdc-public-preview-banner" role="status"><strong>Prévia</strong><span>' . esc_html( $label . $suffix ) . ' · sem cutover</span></div>';
	}

	public static function is_isolation_mode(): bool {
		if ( null === self::preview_kind() ) { return false; }
		$value = isset( $_GET[ self::ISOLATION_KEY ] ) && is_scalar( $_GET[ self::ISOLATION_KEY ] )
			? sanitize_text_field( wp_unslash( (string) $_GET[ self::ISOLATION_KEY ] ) )
			: '';
		return '1' === $value;
	}

	/** @param array<int,string> $theme_uris */
	private static function is_theme_asset_source( string $src, array $theme_uris ): bool {
		if ( '' === $src ) { return false; }
		if ( false !== strpos( $src, '/wp-content/themes/' ) ) { return true; }
		foreach ( $theme_uris as $theme_uri ) {
			if ( '' !== $theme_uri && 0 === strpos( $src, $theme_uri ) ) { return true; }
		}
		return false;
	}

	private static function render_brand_visual(): void {
		$logo_id = absint( get_theme_mod( 'custom_logo', 0 ) );
		if ( $logo_id > 0 ) {
			$url = wp_get_attachment_image_url( $logo_id, 'thumbnail' );
			if ( is_string( $url ) && '' !== $url ) { echo '<span class="bdc-public-brand__logo"><img src="' . esc_url( $url ) . '" alt="" aria-hidden="true"></span>'; return; }
		}
		echo '<span class="bdc-public-brand__mark" aria-hidden="true">BDC</span>';
	}

	private static function global_query(): string {
		return isset( $_GET[ self::GLOBAL_QUERY_KEY ] ) && is_scalar( $_GET[ self::GLOBAL_QUERY_KEY ] ) ? sanitize_text_field( wp_unslash( (string) $_GET[ self::GLOBAL_QUERY_KEY ] ) ) : '';
	}

	private static function preview_kind(): ?string {
		if ( is_admin() || ! current_user_can( 'manage_options' ) ) { return null; }
		$kind = isset( $_GET[ self::QUERY_KEY ] ) && is_scalar( $_GET[ self::QUERY_KEY ] ) ? sanitize_key( wp_unslash( (string) $_GET[ self::QUERY_KEY ] ) ) : '';
		if ( ! in_array( $kind, array( 'home', 'article' ), true ) ) { return null; }
		$nonce = isset( $_GET[ self::NONCE_KEY ] ) && is_scalar( $_GET[ self::NONCE_KEY ] ) ? sanitize_text_field( wp_unslash( (string) $_GET[ self::NONCE_KEY ] ) ) : '';
		return wp_verify_nonce( $nonce, 'bdc_kb_public_preview_' . $kind ) ? $kind : null;
	}
}